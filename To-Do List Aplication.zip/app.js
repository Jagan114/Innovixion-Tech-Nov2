const todoList = document.getElementById('todo-list');

    function addTodo() {
        const newTaskInput = document.getElementById('new-task');
        const todoText = newTaskInput.value.trim();

        if (todoText) {
            const todoItem = document.createElement('li');
            todoItem.className = 'todo-item';
            todoItem.innerHTML = `
                <span>${todoText}</span>
                <button class="edit-btn" onclick="editTodo(this)">Edit</button>
                <button class="delete-btn" onclick="deleteTodo(this)">Delete</button>
            `;
            todoList.appendChild(todoItem);
            newTaskInput.value = '';
        }
    }

    function deleteTodo(btn) {
        const listItem = btn.parentElement;
        todoList.removeChild(listItem);
    }

    function editTodo(btn) {
        const listItem = btn.parentElement;
        const taskText = listItem.querySelector('span').innerText;
        const newTask = prompt('Edit Task:', taskText);

        if (newTask !== null) {
            listItem.querySelector('span').innerText = newTask;
        }
    }